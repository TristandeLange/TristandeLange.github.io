<!-- Footer -->
		<footer class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1 class="logo-text"><span>TD</span>Lange</h1>
					<p>
						TDLange is a blog and portfolio website made by Tristan de Lange. I'll be posting about my travels, game development(both mine and others), interviews with other indie developers, and whatever else catches my interest. I plan to update this site, add more functionality, and just make it look better over time. 
					</p>
					<div class="contact">
						<span><i class="fas fa-phone"></i> &nbsp;718-839-0596</span>
						<span><i class="fas fa-envelope"></i>&nbsp; tristangdelange@gmail.com</span>
					</div>
					<div class="socials">
						<a href="#"><i class="fab fa-instagram"></i></a>
						<a href="#"><i class="fab fa-youtube"></i></a>
						<a href="#"><i class="fab fa-linkedin"></i></a>
					</div>
				</div>
				<div class="footer-section contact-form">
					<h2>Contact Me!</h2>
					<br>
					<form id="fcf-form-id" class="fcf-form-class" method="post" action="<?php echo BASE_URL . '/contactForm.php'; ?>">
                        <div class="fcf-form-group">
                            <label for="Email" class="fcf-label ">Your email address</label>
                            <div class="fcf-input-group">
                                <input type="email" id="Email" name="Email" class="text-input contact-input" required>
                            </div>
                        <div class="fcf-form-group">
                            <label for="Message" class="fcf-label">Your message</label>
                            <div class="fcf-input-group">
                                <textarea id="Message" name="Message" class="text-input contact-input" rows="3" maxlength="3000" required></textarea>
                            </div>
                        </div>
                            <div class="fcf-form-group">
                                <button type="submit" id="fcf-button" class="btn btn-big contact-btn">
                                    <i class="fas fa-envelope"></i>
                                    Send</button>
                            </div>
        				</div>	
    				</form>
			    </div>


			<div class="footer-bottom">
				&copy; Designed by Tristan de Lange
			</div>
		</footer>
		<!-- // Footer -->